package com.tmsteam2.callHistory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CallHistoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(CallHistoryApplication.class, args);
	}

}

