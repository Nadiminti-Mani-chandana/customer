package com.tmsteam2.callHistory.exception;
public class CallNotFoundException extends RuntimeException {
    public CallNotFoundException(String message) {
        super(message);
    }
}

