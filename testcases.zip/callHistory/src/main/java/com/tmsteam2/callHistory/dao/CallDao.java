package com.tmsteam2.callHistory.dao;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tmsteam2.callHistory.model.Call;



@Repository
//@Component
public interface CallDao  extends JpaRepository<Call,Integer>
{

List<Call> getCallByfromId(@Param("fromId")Integer fromId);
List<Call> getCallBytoId(@Param("toId")Integer tid);
List<Call> getCallBytotalTime(@Param("totalTime")Float totalTime);
List<Call> getCallByplanId(@Param("planId")Integer planId);
}

