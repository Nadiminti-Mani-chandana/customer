package com.tmsteam2.callHistory.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.tmsteam2.callHistory.model.Call;
import com.tmsteam2.callHistory.services.CallServices;




@RestController
public class CallController {
	@Autowired
	CallServices callServices;
	@GetMapping("/callfrom/{fromid}")
	public List<Call> getCallByfromId(@PathVariable Integer fromid) {
		return callServices.getCallByfromId(fromid);
	}
	@GetMapping("/callto/{toid}")
	public List<Call> getCallBytoId(@PathVariable Integer toid) {
		return callServices.getCallBytoId(toid);
	}
	@GetMapping("/getalldetails")
	public List<Call> getAllDetails1() {
		return callServices.getAllDetails();
	}
	@GetMapping("/callcid/{callid}")
public Call getCallBycallId(@PathVariable Integer callid) {
		
		return callServices.getCallId(callid);
	}
	@GetMapping("/calltt/{calltotaltime}")
	public List<Call> getCallBytotaltime(@PathVariable Float totaltime) {
			
			return callServices.getCallBytotaltime(totaltime);
  }
	@GetMapping("/callplan/{planId}")
	public List<Call> getCallByplanId(@PathVariable Integer planId) {
		return callServices.getCallByplanId(planId);

	}
@PostMapping("/call") 
public String  addcallDetails(@RequestBody	  Call call) {
	    String result= callServices.addCall(call);
	  return  result;

}
/*
@PutMapping("/call") 
public Call updateCallDetails(@PathVariable("callId") Integer callId,@RequestBody Call call) {
	
	return  callServices.updateCall(callId, call); 
}

@DeleteMapping("/call") 
public Call deleteCallDetails(@PathVariable("callId") Integer callId) {
	
	return callServices.deleteCall(callId);
}*/


}

