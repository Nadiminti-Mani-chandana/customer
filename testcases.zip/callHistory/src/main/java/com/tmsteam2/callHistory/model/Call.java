package com.tmsteam2.callHistory.model;
import java.time.LocalDateTime;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Call {
@Id
Integer callId;
Integer fromId;
Integer toId;
LocalDateTime startTime;
LocalDateTime endTime;
Float totalTime;
Integer planId;
public Call(){
}

public Call(Integer callId, Integer fromId, Integer toId,LocalDateTime startTime,
		LocalDateTime endTime, Float totalTime, Integer planId) {
	super();
	this.callId = callId;
	this.fromId = fromId;
	this.toId = toId;
	this.startTime = startTime;
	this.endTime = endTime;
	this.totalTime = totalTime;
	this.planId = planId;
}
@Override
public String toString() {
	return "Call [callId=" + callId + ", fromId=" + fromId + ", toId=" + toId + ", startTime="
			+ startTime + ", endTime=" + endTime + ", totalTime=" + totalTime + ", planId=" + planId + "]";
}
public Integer getCallId() {
	return callId;
}
public void setCallId(Integer callId) {
	this.callId = callId;
}
public Integer getFromId() {
	return fromId;
}
public void setFromId(Integer fromId) {
	this.fromId = fromId;
}
public Integer getToId() {
	return toId;
}
public void setToId(Integer toId) {
	this.toId = toId;
}
public LocalDateTime getStartTime() {
	return startTime;
}
public void setStartTime(LocalDateTime startTime) {
	this.startTime = startTime;
}
public LocalDateTime getEndTime() {
	return endTime;
}
public void setEndTime(LocalDateTime endTime) {
	this.endTime = endTime;
}
public Float getTotalTime() {
	return totalTime;
}
public void setTotalTime(Float totalTime) {
	this.totalTime = totalTime;
}
public Integer getPlanId() {
	return planId;
}
public void setPlanId(Integer planId) {
	this.planId = planId;
}
}

