package com.tmsteam2.callHistory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CallHistoryApplicationTests {

	@Test
	void contextLoads() {
	}

}

