package com.tmsteam2.callHistory.services;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.tmsteam2.callHistory.dao.CallDao;
import com.tmsteam2.callHistory.model.Call;

@SpringBootTest
	@ActiveProfiles("test")  // Optional: if you have a specific test profile
	public class CallServicesTest {

	    @Mock
	    private CallDao callDao;

	    @InjectMocks
	    private CallServices callServices;

	    @BeforeEach
	    public void setUp() {
	        MockitoAnnotations.openMocks(this);
	    }

	    @Test
	    public void testGetCallByfromId() {
	        Integer fromId = 1;
	        List<Call> mockCalls = new ArrayList<>();
	        mockCalls.add(new Call());  // Add relevant Call objects as needed

	        when(callDao.getCallByfromId(fromId)).thenReturn(mockCalls);

	        List<Call> result = callServices.getCallByfromId(fromId);
	        assertEquals(mockCalls, result);
	    }

	    @Test
	    public void testAddCall() {
	        Call call = new Call();
	        when(callDao.save(call)).thenReturn(call);

	        String result = callServices.addCall(call);
	        assertEquals("Added", result);
	        verify(callDao, times(1)).save(call);
	    }

	    @Test
	    public void testGetCallId() {
	        Integer callId = 1;
	        Call call = new Call();
	        when(callDao.findById(callId)).thenReturn(Optional.of(call));

	        Call result = callServices.getCallId(callId);
	        assertNotNull(result);
	        assertEquals(call, result);
	    }

	    @Test
	    public void testUpdateCall() {
	        Integer callId = 1;
	        Call existingCall = new Call();
	        existingCall.setTotalTime(10.0f);

	        Call updatedCall = new Call();
	        updatedCall.setTotalTime(20.0f);

	        when(callDao.findById(callId)).thenReturn(Optional.of(existingCall));
	        when(callDao.save(existingCall)).thenReturn(existingCall);

	        Call result = callServices.updateCall(callId, updatedCall);
	        assertNotNull(result);
	        assertEquals(20.0f, result.getTotalTime());
	    }

	    @Test
	    public void testDeleteCall() {
	        Integer callId = 1;
	        Call call = new Call();

	        when(callDao.findById(callId)).thenReturn(Optional.of(call));
	        doNothing().when(callDao).deleteById(callId);

	        Call result = callServices.deleteCall(callId);
	        assertNotNull(result);
	        verify(callDao, times(1)).deleteById(callId);
	    }

	    @Test
	    public void testGetAllDetails() {
	        List<Call> mockCalls = new ArrayList<>();
	        mockCalls.add(new Call());  // Add relevant Call objects as needed

	        when(callDao.findAll()).thenReturn(mockCalls);

	        List<Call> result = callServices.getAllDetails();
	        assertEquals(mockCalls, result);
	    }
	    
	    @Test
	    public void testGetCallBytotaltime() {
	        Float totalTime = 10.0f;
	        List<Call> mockCalls = new ArrayList<>();
	        mockCalls.add(new Call());  // Add relevant Call objects as needed

	        when(callDao.getCallBytotalTime(totalTime)).thenReturn(mockCalls);

	        List<Call> result = callServices.getCallBytotaltime(totalTime);
	        assertEquals(mockCalls, result);
	    }
	}

